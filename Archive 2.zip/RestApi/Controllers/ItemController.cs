﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace RestApi.Controllers
{
    [ApiController]
    [Route("api/[controller]")]

    public class ItemController : Controller
    {
        private readonly MyDBContext _context;

        public  ItemController(MyDBContext context)
        {
            _context = context;
        }
        [HttpGet]
        public ActionResult<IEnumerable<Item>> Get()
        {
            return _context.Items.ToList();
        }

        [HttpGet("{id}")]
        public ActionResult<Item> Get(int id)
        {
            var Item = _context.Items.Find(id);
            if (Item == null)
            {
                return NotFound();
            }
            return Item;
        }

        [HttpPost]
        public ActionResult<Item> Post([FromBody] Item Item)
        {
            _context.Add(Item);
            _context.SaveChanges();
            return CreatedAtAction(nameof(Get), new { id = Item.id }, Item);
        }

        [HttpDelete("{id}")]
        public ActionResult<Item> Delete(int id)
        {
            var Item = _context.Items.Find(id);
            if (Item == null)
            {
                return NotFound();
            }
            _context.Items.Remove(Item);
            _context.SaveChanges();
            return Item;
        }
    }
}


