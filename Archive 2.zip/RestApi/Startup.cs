﻿using System;
using Microsoft.EntityFrameworkCore;

namespace RestApi
{
    public class Startup
    {
        public void ConfigureServices(IServiceCollection services)
        {
            //Add the context
            services.AddDbContext<MyDBContext>(options =>
                options.UseSqlite("Data Source=mydb.db"));
            services.AddControllers();
        }
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            using (var serviceScope = app.ApplicationServices.GetService<IServiceScopeFactory>().CreateScope())
            {
                var context = serviceScope.ServiceProvider.GetRequiredService<MyDBContext>();
                context.Database.EnsureCreated();
            }
        }
    }
}