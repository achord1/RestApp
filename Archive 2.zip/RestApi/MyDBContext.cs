﻿using System;
using Microsoft.EntityFrameworkCore;

namespace RestApi
{
	public class MyDBContext: DbContext
	{
        public MyDBContext(DbContextOptions<MyDBContext> options) : base(options)
        {
        }
        public DbSet<Item> Items => Set<Item>();
    }
}

