﻿using System;
using System.ComponentModel.DataAnnotations;

namespace RestApi
{
    public class Item
    {
        [Key]
        public int id { get; set; }
        public string name { get; set; } = string.Empty;
        public double price { get; set; }
    }
}

