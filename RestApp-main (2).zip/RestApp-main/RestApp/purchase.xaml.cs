﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace RestApp
{
    public partial class purchase : ContentPage
    {
        static HttpClient client = new HttpClient();
       static async Task RunAsync() {
            client.BaseAddress = new Uri("http:\\localhost:64195\");
                client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Accept.Add(
                new MediaTypeWithQualityHeaderValue("application/json"));
            try {
                product Product = new product() ;
                id = 2;
                
                
            }

        }
        static async Task<product> GetProductAsync(string path) {
            product product = null;
            HttpRequestMessage response=await client.GetAsync(path);
            if (response.IsSuccessStatusCode) { 
            product=response.Content.ReadAsAsync<product>()}
            return product;


        }*/
        public purchase()
        {
            InitializeComponent();
           
        }
        //api connection begin
        public class product
        { 
        public int id { get; set; }
            public string item { get; set; }

        }
        //api connection end

        private async void goPurchase(object sender, EventArgs e)
        {
            
           

            string sPurchases = "";
            float iTotPrice = 0;
            if(swBurger.IsToggled){
               
                sPurchases = sPurchases + "Burger,";
                int iBurg = 0;
                try {
                    iBurg = int.Parse(edtBurg.Text);

                }
                catch (Exception ex)
                {
                    iBurg= 1;

                }
                iTotPrice += 20*iBurg;
            }
            if (swChips.IsToggled)
            {
                sPurchases = sPurchases + "Chips,";
                int iChips = 0;
                try
                {
                     iChips = int.Parse(edtChips.Text);

                }
                catch(Exception) { 
                    iChips = 1; 
                }
                iTotPrice += 10 * iChips;


            }
            if (swWater.IsToggled) {
                sPurchases = sPurchases + "Water,";
                int iWater = 0;
                try
                {
                     iWater = int.Parse(edtWater.Text);
                   
                }catch(Exception) {
                    iWater= 1;
                }
                iTotPrice += 5 * iWater;


            }
            if (swWrap.IsToggled)
            {

                sPurchases = sPurchases + "Wrap,";
                int iWrap = 0;
                try
                {
                    iWrap = int.Parse(edtWrap.Text);
                   
                }
                catch(Exception ex)
                {
                     iWrap = 1;
                    
                }
                iTotPrice += 30 * iWrap;

            }
            if (iTotPrice==0) {
                
                lblPurchase.Text = "You have not selected anything to purchase.Please select something.";
                lblPurchase.BackgroundColor= Color.PaleVioletRed;
            }
            else
            {


                lblPurchase.Text = "Thank you for purchasing " + sPurchases + ".That will cost R" + iTotPrice + " have a nice day.";
                lblPurchase.BackgroundColor = Color.LightSkyBlue;

            }
        }
    }
}