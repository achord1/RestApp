﻿namespace ProductCrudAPI
{
    public class testclass
    {
        public int Name { get; set; }
    }
}
