﻿namespace ProductCrudAPI.Data
{
    public class DataContexts:DbContexts
    {
      public DataContexts(DbContextOptions)

    }
}
